import java.util.ArrayList;

public class Estoque {
    private ArrayList<Produto> listaDeProdutos;

    public Estoque() {
        this.listaDeProdutos = new ArrayList<>();
    }

    // Método para adicionar um produto ao estoque
    public void adicionarProduto(Produto produto) {
        listaDeProdutos.add(produto);
        System.out.println("Produto adicionado ao estoque: " + produto.getDescricao());
    }

    // Método para remover um produto do estoque
    public void removerProduto(int codigo) {
        Produto produto = buscarProduto(codigo);
        if (produto != null) {
            listaDeProdutos.remove(produto);
            System.out.println("Produto removido do estoque: " + produto.getDescricao());
        } else {
            System.out.println("Produto não encontrado.");
        }
    }

    // Método para buscar um produto no estoque
    public Produto buscarProduto(int codigo) {
        for (Produto p : listaDeProdutos) {
            if (p.getCodigo() == codigo) {
                return p;
            }
        }
        return null; // Produto não encontrado
    }

    // Método para listar todos os produtos no estoque
    public void listarProdutos() {
        if (listaDeProdutos.isEmpty()) {
            System.out.println("Estoque vazio.");
        } else {
            for (Produto p : listaDeProdutos) {
                p.visualizarEstoque();
            }
        }
    }

    // Método para atualizar a quantidade em estoque de um produto
    public void atualizarEstoque(int codigo, int quantidade, boolean entrada) {
        Produto produto = buscarProduto(codigo);
        if (produto != null) {
            if (entrada) {
                produto.entradaDeProdutos(quantidade);
            } else {
                produto.saidaDeProdutos(quantidade);
            }
        } else {
            System.out.println("Produto não encontrado.");
        }
    }

    public static void main(String[] args) {
        Estoque estoque = new Estoque();
        
        // Adicionando alguns produtos para testes
        Produto produto1 = new Produto(1, "Produto A");
        Produto produto2 = new Produto(2, "Produto B");

        estoque.adicionarProduto(produto1);
        estoque.adicionarProduto(produto2);

        // Exibir todos os produtos
        estoque.listarProdutos();

        // Atualizar estoque
        estoque.atualizarEstoque(1, 10, true); // Entrada de 10 unidades do Produto A
        estoque.atualizarEstoque(2, 5, true); // Entrada de 5 unidades do Produto B

        // Exibir estoque atualizado
        estoque.listarProdutos();

        // Retirar produtos do estoque
        estoque.atualizarEstoque(1, 2, false); // Saída de 2 unidades do Produto A

        // Exibir estoque após retirada
        estoque.listarProdutos();

        // Remover um produto do estoque
        estoque.removerProduto(2); // Remove Produto B

        // Exibir estoque final
        estoque.listarProdutos();
    }
}
