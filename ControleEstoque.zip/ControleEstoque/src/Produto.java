public class Produto {
    private int codigo;
    private String descricao;
    private int quantidadeEmEstoque;

    public Produto(int codigo, String descricao) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.quantidadeEmEstoque = 0; // Inicializa o estoque como 0
    }

    // Getters e Setters
    public int getCodigo() { return codigo; }
    public String getDescricao() { return descricao; }
    public int getQuantidadeEmEstoque() { return quantidadeEmEstoque; }
    public void setQuantidadeEmEstoque(int quantidade) { this.quantidadeEmEstoque = quantidade; }

    // Métodos para manipulação de estoque
    public void entradaDeProdutos(int quantidade) {
        if (quantidade > 0) {
            this.quantidadeEmEstoque += quantidade;
            System.out.println(quantidade + " unidades adicionadas ao estoque.");
        } else {
            System.out.println("Quantidade inválida para entrada de produtos.");
        }
    }

    public void saidaDeProdutos(int quantidade) {
        if (quantidade > 0 && quantidade <= this.quantidadeEmEstoque) {
            this.quantidadeEmEstoque -= quantidade;
            System.out.println(quantidade + " unidades retiradas do estoque.");
        } else {
            System.out.println("Quantidade inválida para saída de produtos.");
        }
    }

    public void visualizarEstoque() {
        System.out.println("Código: " + this.codigo);
        System.out.println("Descrição: " + this.descricao);
        System.out.println("Quantidade em estoque: " + this.quantidadeEmEstoque);
    }
}
